<h1>Create New User</h1>
<form method="post">
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    <label for="heslo">Password:</label>
    <input type="password" name="heslo" id="heslo" required>
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" required>
    <label for="surname">Surname:</label>
    <input type="text" name="surname" id="surname" required>
    <label for="admin">Admin (1 = Yes, 0 = No):</label>
    <input type="number" name="admin" id="admin" required>
    <button type="submit">Create</button>
</form>
