<h1><?= htmlspecialchars($category['nazev_kategorie']); ?></h1>
<p>URL: <?= htmlspecialchars($category['url']); ?></p>