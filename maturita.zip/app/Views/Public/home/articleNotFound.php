<h1>Article Not Found</h1>
<p>The article you are looking for does not exist or is not visible.</p>
<a href="?controller=Home&action=index">Back to Home</a>
